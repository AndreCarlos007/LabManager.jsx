"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../../components/ui/card"
import { Badge } from "../../../components/ui/badge"
import { Button } from "../../../components/ui/button"
import {
  Calendar,
  Users,
  Building2,
  GraduationCap,
  Clock,
  CheckCircle,
  XCircle,
  TrendingUp,
  Activity,
  BookOpen,
  Settings,
  Plus,
  Eye,
  ArrowRight,
} from "lucide-react"
import Cookies from "js-cookie"
import { getUserProfile } from "../../../lib/api"
import Link from "next/link"

export default function DashboardPage() {
  const [userProfile, setUserProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalReservas: 0,
    reservasPendentes: 0,
    reservasAprovadas: 0,
    reservasRejeitadas: 0,
    totalLaboratorios: 0,
    totalTurmas: 0,
    totalUsuarios: 0,
  })

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const token = Cookies.get("token")
        if (token) {
          const profile = await getUserProfile(token)
          setUserProfile(profile)
        }
      } catch (error) {
        console.error("Erro ao carregar perfil:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUserProfile()
    // Simular carregamento de estatísticas
    setTimeout(() => {
      setStats({
        totalReservas: 45,
        reservasPendentes: 12,
        reservasAprovadas: 28,
        reservasRejeitadas: 5,
        totalLaboratorios: 8,
        totalTurmas: 15,
        totalUsuarios: 32,
      })
    }, 1000)
  }, [])

  const getFuncaoColor = (funcao) => {
    switch (funcao) {
      case 1:
        return "bg-blue-500"
      case 2:
        return "bg-green-500"
      case 3:
        return "bg-purple-500"
      default:
        return "bg-gray-500"
    }
  }

  const getFuncaoLabel = (funcao) => {
    switch (funcao) {
      case 1:
        return "Coordenador de Curso"
      case 2:
        return "Coordenador de Laboratório"
      case 3:
        return "Reitoria"
      default:
        return "Usuário"
    }
  }

  const quickActions = [
    {
      title: "Nova Reserva",
      description: "Criar uma nova reserva de laboratório",
      icon: Plus,
      href: "/dashboard/reservas",
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      title: "Ver Reservas",
      description: "Visualizar todas as reservas",
      icon: Eye,
      href: "/dashboard/reservas",
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      title: "Gerenciar Labs",
      description: "Administrar laboratórios",
      icon: Building2,
      href: "/dashboard/laboratorios",
      color: "bg-purple-500 hover:bg-purple-600",
    },
    {
      title: "Configurações",
      description: "Ajustar configurações do sistema",
      icon: Settings,
      href: "/dashboard/configuracoes",
      color: "bg-gray-500 hover:bg-gray-600",
    },
  ]

  const moduleCards = [
    {
      title: "Reservas de Laboratórios",
      description: "Gerencie reservas, aprovações e fluxo de trabalho",
      icon: Calendar,
      href: "/dashboard/reservas",
      stats: [
        { label: "Total", value: stats.totalReservas, color: "text-blue-600" },
        { label: "Pendentes", value: stats.reservasPendentes, color: "text-yellow-600" },
        { label: "Aprovadas", value: stats.reservasAprovadas, color: "text-green-600" },
      ],
      features: ["Fluxo de aprovação em 3 etapas", "Controle por função", "Histórico completo"],
    },
    {
      title: "Laboratórios",
      description: "Cadastro e gerenciamento de laboratórios",
      icon: Building2,
      href: "/dashboard/laboratorios",
      stats: [
        { label: "Total", value: stats.totalLaboratorios, color: "text-purple-600" },
        { label: "Disponíveis", value: stats.totalLaboratorios - 2, color: "text-green-600" },
        { label: "Em uso", value: 2, color: "text-orange-600" },
      ],
      features: ["Cadastro completo", "Status em tempo real", "Localização e recursos"],
    },
    {
      title: "Turmas",
      description: "Gestão de turmas e disciplinas",
      icon: GraduationCap,
      href: "/dashboard/turmas",
      stats: [
        { label: "Total", value: stats.totalTurmas, color: "text-indigo-600" },
        { label: "Ativas", value: stats.totalTurmas - 3, color: "text-green-600" },
        { label: "Arquivadas", value: 3, color: "text-gray-600" },
      ],
      features: ["Organização por período", "Vinculação com professores", "Histórico acadêmico"],
    },
    {
      title: "Usuários",
      description: "Controle de acesso e permissões",
      icon: Users,
      href: "/dashboard/usuarios",
      stats: [
        { label: "Total", value: stats.totalUsuarios, color: "text-teal-600" },
        { label: "Ativos", value: stats.totalUsuarios - 5, color: "text-green-600" },
        { label: "Inativos", value: 5, color: "text-red-600" },
      ],
      features: ["Controle de funções", "Permissões granulares", "Auditoria de acesso"],
    },
  ]

  const recentActivities = [
    {
      id: 1,
      type: "reserva_aprovada",
      message: "Reserva do Lab. Informática aprovada",
      time: "2 min atrás",
      icon: CheckCircle,
      color: "text-green-600",
    },
    {
      id: 2,
      type: "nova_reserva",
      message: "Nova reserva criada para Lab. Química",
      time: "15 min atrás",
      icon: Calendar,
      color: "text-blue-600",
    },
    {
      id: 3,
      type: "reserva_rejeitada",
      message: "Reserva do Lab. Física rejeitada",
      time: "1 hora atrás",
      icon: XCircle,
      color: "text-red-600",
    },
    {
      id: 4,
      type: "usuario_cadastrado",
      message: "Novo usuário cadastrado no sistema",
      time: "2 horas atrás",
      icon: Users,
      color: "text-purple-600",
    },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-6 space-y-8 ml-6">
      {/* Header com boas-vindas */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Olá, {userProfile?.nome || "Usuário"}! 👋</h1>
          <p className="text-gray-600 mt-1">Bem-vindo ao sistema de gerenciamento de laboratórios</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Badge className={`${getFuncaoColor(userProfile?.funcao)} text-white px-3 py-1`}>
            {getFuncaoLabel(userProfile?.funcao)}
          </Badge>
        </div>
      </div>

      {/* Cards de estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total de Reservas</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalReservas}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pendentes</p>
                <p className="text-2xl font-bold text-gray-900">{stats.reservasPendentes}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Aprovadas</p>
                <p className="text-2xl font-bold text-gray-900">{stats.reservasAprovadas}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Laboratórios</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalLaboratorios}</p>
              </div>
              <Building2 className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ações rápidas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Ações Rápidas
          </CardTitle>
          <CardDescription>Acesse rapidamente as funcionalidades principais</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Link key={index} href={action.href}>
                <Button className={`w-full h-auto p-4 ${action.color} text-white flex flex-col items-center gap-2`}>
                  <action.icon className="h-6 w-6" />
                  <div className="text-center">
                    <div className="font-medium">{action.title}</div>
                    <div className="text-xs opacity-90">{action.description}</div>
                  </div>
                </Button>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Grid principal com módulos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {moduleCards.map((module, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    <module.icon className="h-6 w-6 text-gray-700" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{module.title}</CardTitle>
                    <CardDescription>{module.description}</CardDescription>
                  </div>
                </div>
                <Link href={module.href}>
                  <Button variant="ghost" size="sm">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Estatísticas do módulo */}
              <div className="grid grid-cols-3 gap-4">
                {module.stats.map((stat, statIndex) => (
                  <div key={statIndex} className="text-center">
                    <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                    <div className="text-xs text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* Features do módulo */}
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">Principais recursos:</p>
                <ul className="space-y-1">
                  {module.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <Link href={module.href}>
                <Button className="w-full" variant="outline">
                  Acessar {module.title}
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Atividades recentes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Atividades Recentes
          </CardTitle>
          <CardDescription>Últimas ações realizadas no sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                <div className={`p-2 rounded-full bg-white ${activity.color}`}>
                  <activity.icon className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-center">
            <Button variant="ghost" size="sm">
              Ver todas as atividades
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Footer da dashboard */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-none">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Sistema Lab Manager</h3>
              <p className="text-gray-600">Gerenciamento inteligente de laboratórios acadêmicos</p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center gap-4">
              <Badge variant="outline" className="bg-white">
                v1.0.0
              </Badge>
              <Button variant="ghost" size="sm">
                <BookOpen className="h-4 w-4 mr-2" />
                Documentação
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
