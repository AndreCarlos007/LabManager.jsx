"use client";
import LoginForm from "../../../components/forms/loginForm/page";


export default function LoginPage() {
  return (
    <div className="">
        <LoginForm />
    </div>
  );
}
