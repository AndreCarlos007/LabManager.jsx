import React from 'react'

import RegisterForm from '../../../components/forms/registerForm/page'
const page = () => {
  return (
    <div>
      <RegisterForm />
    </div>
  )
}

export default page
